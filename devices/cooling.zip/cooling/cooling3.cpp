#include "cooling3.h"
#include "ui_cooling3.h"

Cooling3::Cooling3(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Cooling3)
{
    ui->setupUi(this);

    connect(this,SIGNAL(newPacketReceived(QByteArray)),&pManager,SLOT(packetReceived(QByteArray)));
    connect(&pManager,&packetManager::newDataUpdate,this,&Cooling3::GuiUpdate);

    timerSendCoolerData.setInterval(50);
    connect(&timerSendCoolerData, &QTimer::timeout, this, &Cooling3::sendCoolerDataSlot);

    if(autoMode){
        on_BtnAuto_clicked();
    }
    else {
        on_BtnManual_clicked();
    }

    ui->BtnAuto->setEnabled(false);
    ui->BtnManual->setEnabled(false);
}

Cooling3::~Cooling3()
{
    timerSendCoolerData.stop();
    delete ui;
}


void Cooling3::on_DeviceResponseSlot(QByteArray dataReceiced)
{
    emit newPacketReceived(dataReceiced);
}

void Cooling3::connectionStatusSlot(bool val)
{


    isCoolerConnected = val;

    if(status_mode == Cooler_Off and isCoolerConnected)
    {
        on_BtnTurnOffCooling_clicked();
    }
    else if(status_mode == Cooler_On and isCoolerConnected)
    {
        on_BtnTurnOnCooling_clicked();
    }

    ui->BtnManual->setEnabled(val);
    ui->BtnAuto->setEnabled(val);

    ui->BtnTurnOnCooling->setEnabled(val);
    ui->BtnTurnOffCooling->setEnabled(val);
    //turn on compresor
    uint8_t data[]={1,0,1,ON};
    creatPacket(1,data,4,FC_WriteMultReg);
}


//=======================Btn function=========================================
void Cooling3::on_BtnAuto_clicked()
{
    autoMode = true;
    ui->BtnAuto->setStyleSheet("background-color: #186a3b");
    ui->BtnManual->setStyleSheet("background-color: black");
    ui->BtnTurnOnCooling->setVisible(false);
    ui->BtnTurnOffCooling->setVisible(false);
    //emit sendCommandToDeviceSignal("");
}

void Cooling3::on_BtnManual_clicked()
{
    autoMode = false;
    ui->BtnTurnOnCooling->setVisible(true);
    ui->BtnTurnOffCooling->setVisible(true);
    ui->BtnAuto->setStyleSheet("background-color: black");
    ui->BtnManual->setStyleSheet("background-color: #186a3b");

    if(isCoolerConnected){
        on_BtnTurnOffCooling_clicked();
    }

}

void Cooling3::on_BtnTurnOnCooling_clicked()
{
    status_mode = Cooler_On;
    timerSendCoolerData.start();
}


bool Cooling3::creatPacket(uint8_t slaveNumber,uint8_t *data,uint8_t dataLen,FC_t fc)
{


    QByteArray dOut;
    uint8_t index=0;


    dOut[index++]=(uint8_t)(_HEADER_>>8);
    dOut[index++]=(uint8_t)(_HEADER_);

    dOut[index++]=(uint8_t)(slaveNumber>>8);
    dOut[index++]=(uint8_t)(slaveNumber);

    dOut[index++]=(dataLen+10)>>8; // 10 = FixByte
    dOut[index++]=(dataLen+10);

    dOut[index++]=fc;
    dOut[index++]=dataLen;

    for (int i = 0; i < dataLen; ++i)
    {
        dOut[index++]=data[i];
    }
    dOut[index++]=(uint8_t)(_FOOTER_>>8);
    dOut[index++]=(uint8_t)(_FOOTER_);


    emit sendCommandToDeviceSignal(dOut);
    //    tcpClient.write(dOut);

    return true;
}
void Cooling3::on_BtnTurnOffCooling_clicked()
{
    status_mode = Cooler_Off;
    timerSendCoolerData.start();
}



bool flagReadCalibAdcValueGui=false;
bool flagReadDefaultGui=false;



void Cooling3::GuiUpdate(packetManager::CoolingBoard_t CoolingBoard)
{ 
    if(flagReadDefaultGui==true)
    {
        flagReadDefaultGui=false;
        //        reloadeDefaultGui();
        return;
    }
    if(flagReadCalibAdcValueGui==true)
    {
        flagReadCalibAdcValueGui=false;
        //        reloadeCalibAdcValueFun();
        return;
    }

    if(CoolingBoard.COMPRESSOR.State==packetManager::ON)
    {
        ui->lblComp_2->setText(QString::number(CoolingBoard.COMPRESSOR.Current));
        //ui->btnOnlineCompressorSetStatus->setText("ON");
        //ui->btnOnlineCompressorSetStatus->setStyleSheet("background-color: rgb(40,200,100);");
    }
    else if(CoolingBoard.COMPRESSOR.State==packetManager::OFF)
    {
        ui->lblComp_2->setText(QString::number(0));
        //        ui->pushButton->setText("45"+QString::number(i));
        //ui->btnOnlineCompressorSetStatus->setText("OFF");
        //ui->btnOnlineCompressorSetStatus->setStyleSheet("background-color: rgb(255,255,255);");
        i++;
    }

    if(CoolingBoard.MOTOR.State==packetManager::ON)
    {
        ui->lblMotor_2->setText(QString::number(CoolingBoard.MOTOR.Current));

        //ui->btnOnlineMotorSetStatus->setText("ON");
        //ui->btnOnlineMotorSetStatus->setStyleSheet("background-color: rgb(40,200,100);");
    }
    else if(CoolingBoard.MOTOR.State==packetManager::OFF)
    {

        ui->lblMotor_2->setText(QString::number(0));
        i++;
        //        ui->spinBox->setValue(100);

    }

    if(CoolingBoard.FAN.State==packetManager::ON)
    {

        ui->lblFan_2->setText(QString::number(CoolingBoard.FAN.Current));
        //ui->btnOnlineFanSetStatus->setText("ON");
        //ui->btnOnlineFanSetStatus->setStyleSheet("background-color: rgb(40,200,100);");
    }
    else if(CoolingBoard.FAN.State==packetManager::OFF)
    {

        ui->lblFan_2->setText(QString::number(0));
        //ui->btnOnlineFanSetStatus->setText("OFF");
        //ui->btnOnlineFanSetStatus->setStyleSheet("background-color: rgb(255,255,255);");
    }


    if(CoolingBoard.COMPRESSOR.Error==packetManager::ER_OverCurrent)
    {
        ui->lblComp_2->setText("Over Current");
    }
    else ui->lblComp_2->setText(" ");

    if(CoolingBoard.FAN.Error==packetManager::ER_OverCurrent) ui->lblFan_2->setText("Over Current");
    else ui->lblFan_2->setText(" ");

    if(CoolingBoard.MOTOR.Error==packetManager::ER_OverCurrent) ui->lblMotor_2->setText("Over Current");
    else ui->lblMotor_2->setText(" ");

    //    ui->lblOnlineLevelMeter->setText(QString::number(CoolingBoard.LevelMeter.valuePersent));


}

void Cooling3::sendCoolerDataSlot()
{
    if(count == 0 and status_mode == Cooler_On)
    {
        //turn on fan
        uint8_t fanData[]={1,1,1,ON};
        creatPacket(1,fanData,4,FC_WriteMultReg);
        count++;
    }

    else if(status_mode == Cooler_On){
        //turn on motor
        uint8_t motorData[]={1,2,1,ON};
        creatPacket(1,motorData,4,FC_WriteMultReg);
        count=0;
        timerSendCoolerData.stop();
        ui->BtnTurnOffCooling->setEnabled(true);
        ui->BtnTurnOnCooling->setEnabled(false);

    }


    if(count==0 and status_mode == Cooler_Off)
    {
        //turn off fan
        uint8_t fanData[]={1,1,1,OFF};
        creatPacket(1,fanData,4,FC_WriteMultReg);
        count++;
    }

    else if(status_mode == Cooler_Off) {
        //turn off motor
        uint8_t motorData[]={1,2,1,OFF};
        creatPacket(1,motorData,4,FC_WriteMultReg);
        count=0;
        timerSendCoolerData.stop();
        ui->BtnTurnOnCooling->setEnabled(true);
        ui->BtnTurnOffCooling->setEnabled(false);

    }
}



void Cooling3::on_pushButton_clicked()
{

}


