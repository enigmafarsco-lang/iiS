#include "packetmanager.h"
#include "tcpclient_1.h"


uint8_t packetManager::LT[50]={};
packetManager::CoolingBoard_t packetManager::CoolingBoard={};

packetManager::packetManager()
{
    //    connect(&tcpClient,SIGNAL(newPacketReceived(QByteArray)),this,SLOT(packetReceived(QByteArray)));
}

bool packetManager::connectToBoard(QString Ip, quint16 Port)
{
    tcpClient.connetToHost(Ip,Port);
    return true;
}

bool packetManager::disconnectFromBoard()
{
    tcpClient.disconnect();
    return true;
}

void packetManager::outputSetState(status_t compressorState,status_t motorState,status_t fanState)
{
    uint8_t data[]={1,0,3,(uint8_t)compressorState,(uint8_t)motorState,(uint8_t)fanState};
    creatPacket(1,data,6,FC_WriteMultReg);
}



void packetManager::motorON()
{
    uint8_t data[]={1,2,1,ON};
    creatPacket(1,data,4,FC_WriteMultReg);
}
void packetManager::motorOFF()
{
    uint8_t data[]={1,2,1,OFF};
    creatPacket(1,data,4,FC_WriteMultReg);
}

void packetManager::compressorON()
{
    uint8_t data[]={1,0,1,ON};
    creatPacket(1,data,4,FC_WriteMultReg);
}
void packetManager::compressorOFF()
{
    uint8_t data[]={1,0,1,OFF};
    creatPacket(1,data,4,FC_WriteMultReg);
}

void packetManager::fanON()
{
    uint8_t data[]={1,1,1,ON};
    creatPacket(1,data,4,FC_WriteMultReg);
}
void packetManager::fanOFF()
{
    uint8_t data[]={1,1,1,OFF};
    creatPacket(1,data,4,FC_WriteMultReg);
}

void packetManager::setDefaultValue(CoolingBoard_t model)
{
    uint8_t data[50];
    uint8_t index=0;


    data[index++]=1;
    data[index++]=16;
    data[index++]=11;

    data[index++]=(uint8_t)model.COMPRESSOR.DefState;
    data[index++]=(uint8_t)model.FAN.DefState;
    data[index++]=(uint8_t)model.MOTOR.DefState;

    data[index++]=model.COMPRESSOR.MaxCurrent>>8;
    data[index++]=model.COMPRESSOR.MaxCurrent;

    data[index++]=model.FAN.MaxCurrent>>8;
    data[index++]=model.FAN.MaxCurrent;

    data[index++]=model.MOTOR.MaxCurrent>>8;
    data[index++]=model.MOTOR.MaxCurrent;

    data[index++]=(uint8_t)model.protectionMode;
    data[index++]=(uint8_t)model.dataSendMode;
    creatPacket(1,data,index,FC_WriteMultReg);
}

void packetManager::readOnlineRequest()
{
    uint8_t data[3];
    uint8_t index=0;


    data[index++]=1;
    data[index++]=0;
    data[index++]=16;
    creatPacket(1,data,index,FC_ReadMultReg);
}
void packetManager::readDefaultRequest()
{
    uint8_t data[3];
    uint8_t index=0;


    data[index++]=1;
    data[index++]=16;
    data[index++]=11;
    creatPacket(1,data,index,FC_ReadMultReg);
}
void packetManager::readCalibRequest()
{
    uint8_t data[1];

    data[0]=0;
    creatPacket(1,data,0,FC_ReadCalibXY);
}
void packetManager::readRequestCalibration()
{
    uint8_t data[3];
    uint8_t index=0;


    data[index++]=1;
    data[index++]=27;
    data[index++]=8;
    creatPacket(1,data,index,FC_ReadMultReg);
}

void packetManager::saveCompressorXYValue(double x_,double y_)
{
    uint8_t data[9];
    uint8_t index=0;

    data[index++]=1;
    ///////////////////////////////////////////////////////////////////////////
    int32_t x=(x_*10000);
    int32_t y=(y_*10000);
    //x=100000;

    if(x<0) {data[index]=1; x*=-1;} else data[index]=0;  index++;
    data[index]=x>>16;   index++;
    data[index]=x>>8;    index++;
    data[index]=x;       index++;

    if(y<0) {data[index]=1; y*=-1;} else data[index]=0;   index++;
    data[index]=y>>16;     index++;
    data[index]=y>>8;       index++;
    data[index]=y;    index++;
    creatPacket(1,data,9,FC_WriteCalibXY);
}
void packetManager::saveMotorrXYValue(double x_,double y_)
{
    uint8_t data[9];
    uint8_t index=0;

    data[index++]=3;
    ///////////////////////////////////////////////////////////////////////////
    int32_t x=(x_*10000);
    int32_t y=(y_*10000);
    //x=100000;

    if(x<0) {data[index]=1; x*=-1;} else data[index]=0;  index++;
    data[index]=x>>16;   index++;
    data[index]=x>>8;    index++;
    data[index]=x;       index++;

    if(y<0) {data[index]=1; y*=-1;} else data[index]=0;   index++;
    data[index]=y>>16;     index++;
    data[index]=y>>8;       index++;
    data[index]=y;    index++;
    creatPacket(1,data,9,FC_WriteCalibXY);
}
void packetManager::saveFanXYValue(double x_,double y_)
{
    uint8_t data[9];
    uint8_t index=0;

    data[index++]=2;
    ///////////////////////////////////////////////////////////////////////////
    int32_t x=(x_*10000);
    int32_t y=(y_*10000);
    //x=100000;

    if(x<0) {data[index]=1; x*=-1;} else data[index]=0;  index++;
    data[index]=x>>16;   index++;
    data[index]=x>>8;    index++;
    data[index]=x;       index++;

    if(y<0) {data[index]=1; y*=-1;} else data[index]=0;   index++;
    data[index]=y>>16;     index++;
    data[index]=y>>8;       index++;
    data[index]=y;    index++;
    creatPacket(1,data,9,FC_WriteCalibXY);
}
void packetManager::saveLevelMeterXYValue(double x_,double y_)
{
    uint8_t data[9];
    uint8_t index=0;

    data[index++]=4;
    ///////////////////////////////////////////////////////////////////////////
    int32_t x=(x_*10000);
    int32_t y=(y_*10000);
    //x=100000;

    if(x<0) {data[index]=1; x*=-1;} else data[index]=0;  index++;
    data[index]=x>>16;   index++;
    data[index]=x>>8;    index++;
    data[index]=x;       index++;

    if(y<0) {data[index]=1; y*=-1;} else data[index]=0;   index++;
    data[index]=y>>16;     index++;
    data[index]=y>>8;       index++;
    data[index]=y;    index++;
    creatPacket(1,data,9,FC_WriteCalibXY);
}
void packetManager::FC_ReadCalibXY_Fun(uint8_t *data)
{
    uint8_t index=0;
    int8_t sign=1;
    int32_t x_=0,y_=0;
    double x=0,y=0;
    ///////////////////////////////////////////////////////////////////////////

    if(data[index]==0) sign=1;  else if(data[index]==1) sign=-1;  index++;
    x_=data[index++];
    x_<<=8;
    x_|=data[index++];
    x_<<=8;
    x_|=data[index++];
    x=x_;
    x=x/10000;
    x=x*sign;

    sign=0;
    if(data[index]==0) sign=1;  else if(data[index]==1) sign=-1;   index++;
    y_=data[index++];
    y_<<=8;
    y_|=data[index++];
    y_<<=8;
    y_|=data[index++];
    y=y_;
    y=y/10000;
    y=y*sign;

    CoolingBoard.COMPRESSOR.calibX=x;
    CoolingBoard.COMPRESSOR.calibY=y;
    ///////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////
    sign=0;
    if(data[index]==0) sign=1;  else if(data[index]==1) sign=-1;  index++;
    x_=data[index++];
    x_<<=8;
    x_|=data[index++];
    x_<<=8;
    x_|=data[index++];
    x=x_;
    x=x/10000;
    x=x*sign;

    sign=0;
    if(data[index]==0) sign=1;  else if(data[index]==1) sign=-1;  index++;
    y_=data[index++];
    y_<<=8;
    y_|=data[index++];
    y_<<=8;
    y_|=data[index++];
    y=y_;
    y=y/10000;
    y=y*sign;

    CoolingBoard.FAN.calibX=x;
    CoolingBoard.FAN.calibY=y;
    ///////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////
    sign=0;
    if(data[index]==0) sign=1;  else if(data[index]==1) sign=-1;  index++;
    x_=data[index++];
    x_<<=8;
    x_|=data[index++];
    x_<<=8;
    x_|=data[index++];
    x=x_;
    x=x/10000;
    x=x*sign;

    sign=0;
    if(data[index]==0) sign=1;  else if(data[index]==1) sign=-1;  index++;
    y_=data[index++];
    y_<<=8;
    y_|=data[index++];
    y_<<=8;
    y_|=data[index++];
    y=y_;
    y=y/10000;
    y=y*sign;

    CoolingBoard.MOTOR.calibX=x;
    CoolingBoard.MOTOR.calibY=y;
    ///////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////
    sign=0;
    if(data[index]==0) sign=1;  else if(data[index]==1) sign=-1;  index++;
    x_=data[index++];
    x_<<=8;
    x_|=data[index++];
    x_<<=8;
    x_|=data[index++];
    x=x_;
    x=x/10000;
    x=x*sign;

    sign=0;
    if(data[index]==0) sign=1;  else if(data[index]==1) sign=-1;  index++;
    y_=data[index++];
    y_<<=8;
    y_|=data[index++];
    y_<<=8;
    y_|=data[index++];
    y=y_;
    y=y/10000;
    y=y*sign;

    CoolingBoard.LevelMeter.calib_X=x;
    CoolingBoard.LevelMeter.calib_Y=y;
    ///////////////////////////////////////////////////////////////////////////
    emit readRadyCalibXY();
}
bool packetManager::creatPacket(uint8_t slaveNumber,uint8_t *data,uint8_t dataLen,FC_t fc)
{
    QByteArray dOut;
    uint8_t index=0;


    dOut[index++]=(uint8_t)(_HEADER_>>8);
    dOut[index++]=(uint8_t)(_HEADER_);

    dOut[index++]=(uint8_t)(slaveNumber>>8);
    dOut[index++]=(uint8_t)(slaveNumber);

    dOut[index++]=(dataLen+10)>>8; // 10 = FixByte
    dOut[index++]=(dataLen+10);

    dOut[index++]=fc;
    dOut[index++]=dataLen;

    for (int i = 0; i < dataLen; ++i)
    {
        dOut[index++]=data[i];
    }
    dOut[index++]=(uint8_t)(_FOOTER_>>8);
    dOut[index++]=(uint8_t)(_FOOTER_);

    tcpClient.write(dOut);

    return true;
}



//**

void packetManager::packetReceived(QByteArray dataReceiced)
{
    if (dataReceiced.size()> 29) return;

    dataReceiced = dataReceiced.toHex();
    QByteArray item;
    uint8_t data[100];
    bool ok;
    int index=0;

    for(int i=0;i<dataReceiced.size();i+=2)
    {
        item.append(dataReceiced[i]).append(dataReceiced[i+1]);
        data[index++]=(item.toInt(&ok, 16));
        item.clear();
    }

    checkInputPacket(data);

}
//**
bool packetManager::checkInputPacket(uint8_t *inPack)
{
    uint8_t dataType_;
    dataType_=validationInputPacket(inPack);
    if(dataType_!=0)
    {
        switch(dataType_)
        {

        case FC_ReadMultReg:
            FC_ReadMultReg_Fun(&inPack[8]);
            break;

        case FC_WriteMultReg:
            FC_WriteMultReg_Fun(&inPack[8]);

            break;

        case FC_WriteCalibXY:
            // FC_WriteCalibXY_Fun(&inPack[8]);
            break;

        case FC_ReadCalibXY:
            FC_ReadCalibXY_Fun(&inPack[8]);
            break;
        default:
            QMessageBox msgBox;
            msgBox.setText("Cooling has faced with some problem.");
            msgBox.exec();
            break;
        }

    }

    return false;
}
//**
uint8_t packetManager::validationInputPacket(uint8_t *inPack)
{
    uint8_t result=0;
    packet_t inputPacketTemp;
    uint16_t crc_=0;

    inputPacketTemp.hader=(inPack[0]*256)+inPack[1];
    inputPacketTemp.boardId=(inPack[2]*256)+inPack[3];
    inputPacketTemp.packetLen=(inPack[4]*256)+inPack[5];

    inputPacketTemp.dataType=inPack[6];
    inputPacketTemp.dataLen=inPack[7];
    inputPacketTemp.footer=(inPack[inputPacketTemp.dataLen+8]*256)+inPack[inputPacketTemp.dataLen+9];

    if(inputPacketTemp.hader==_HEADER_)
    {

        if(inputPacketTemp.footer==_FOOTER_)
        {
            result=inputPacketTemp.dataType;
        }
        else
        {
        }
    }
    else
    {
    }
    return result;
}

//**
bool packetManager::FC_ReadMultReg_Fun(uint8_t *data)
{
    uint8_t DatapackLen=data[0];
    uint8_t start=data[1];
    uint8_t len=data[2];
    uint8_t InIndex=3;

    for(uint8_t i=0;i<DatapackLen;i++)
    {
        for(uint8_t j=start;j<start+len;j++)
        {
            LT[j]=data[InIndex++];
        }

        if(DatapackLen>1)
        {
            start=data[InIndex++];
            len=data[InIndex++];
        }
    }

    fillModel();
}

bool packetManager::FC_WriteMultReg_Fun(uint8_t data[])
{
    return true;
}

//**
void packetManager::fillModel()
{
    int index=3;
    if(LT[index]==ON) CoolingBoard.COMPRESSOR.State=ON;
    else if(LT[index]==OFF) CoolingBoard.COMPRESSOR.State=OFF;

    index++;

    if(LT[index]==ON) CoolingBoard.FAN.State=ON;
    else if(LT[index]==OFF) CoolingBoard.FAN.State=OFF;

    index++;

    if(LT[index]==ON) CoolingBoard.MOTOR.State=ON;
    else if(LT[index]==OFF) CoolingBoard.MOTOR.State=OFF;

    index++;

    CoolingBoard.COMPRESSOR.Error=(ERROR_t)LT[index++];
    CoolingBoard.FAN.Error=(ERROR_t)LT[index++];
    CoolingBoard.MOTOR.Error=(ERROR_t)LT[index++];

    CoolingBoard.COMPRESSOR.Current=(LT[index]*256)+LT[index+1]; index+=2;
    CoolingBoard.FAN.Current=(LT[index]*256)+LT[index+1];        index+=2;
    CoolingBoard.MOTOR.Current=(LT[index]*256)+LT[index+1];      index+=2;

    CoolingBoard.LevelMeter.valuePersent=LT[index];  index++;


    if(LT[index]==ON) CoolingBoard.COMPRESSOR.DefState=ON;
    else if(LT[index]==OFF) CoolingBoard.COMPRESSOR.DefState=OFF;
    index++;
    if(LT[index]==ON) CoolingBoard.FAN.DefState=ON;
    else if(LT[index]==OFF) CoolingBoard.FAN.DefState=OFF;
    index++;
    if(LT[index]==ON) CoolingBoard.MOTOR.DefState=ON;
    else if(LT[index]==OFF) CoolingBoard.MOTOR.DefState=OFF;
    index++;

    CoolingBoard.COMPRESSOR.MaxCurrent=(LT[index]*256)+LT[index+1]; index+=2;
    CoolingBoard.FAN.MaxCurrent=(LT[index]*256)+LT[index+1];        index+=2;
    CoolingBoard.MOTOR.MaxCurrent=(LT[index]*256)+LT[index+1];      index+=2;
    CoolingBoard.protectionMode=(protectionMode_t)LT[index];        index++;
    CoolingBoard.dataSendMode=(DataSendMode_t)LT[index];            index++;

    //////////////////////////////////////////////////////////////////////////   Calibration Value

    CoolingBoard.COMPRESSOR.CurrentADCValue=(LT[index]*256)+LT[index+1]; index+=2;
    CoolingBoard.FAN.CurrentADCValue=(LT[index]*256)+LT[index+1]; index+=2;
    CoolingBoard.MOTOR.CurrentADCValue=(LT[index]*256)+LT[index+1]; index+=2;
    CoolingBoard.LevelMeter.AdcValue=(LT[index]*256)+LT[index+1]; index+=2;

    ///////////////////////////////////////////////////////////////////////////////////////////////
    emit newDataUpdate(CoolingBoard);
    //    emit newDataUpdate("CoolingBoard");
}

uint16_t packetManager::CRC16_Calculate( uint8_t *buf,uint16_t len )
{
    uint16_t crc = 0xFFFF;
    char i = 0;

    while(len--)
    {
        crc ^= (*buf++);

        for(i = 0; i < 8; i++)
        {
            if( crc & 1 )
            {
                crc >>= 1;
                crc ^= 0xA001;
            }
            else
            {
                crc >>= 1;
            }
        }
    }

    return crc;
}
