#include "tcpclient_1.h"
#include <QDebug>
TCPClient_1::TCPClient_1(QObject *parent) : QObject(parent)
{
    connect(&socket_tcp,&QTcpSocket::connected,this,&TCPClient_1::connected);

    connect(&socket_tcp,&QTcpSocket::disconnected,this,&TCPClient_1::disconnected);

    connect(&socket_tcp,&QTcpSocket::stateChanged,this,&TCPClient_1::stateChanged);

    connect(&socket_tcp,&QTcpSocket::readyRead,this,&TCPClient_1::readyRead);

    connect(&socket_tcp,QOverload<QAbstractSocket::SocketError>::of(&QAbstractSocket::error),this,&TCPClient_1::error);
}

void TCPClient_1::connetToHost(QString host,quint16 port)
{
    /*
     * For UDP only one socket cab be opened at the same time so it should be closed first
    */
    if(socket_tcp.isOpen()) disconnect();

    qInfo() <<"Connecting to "<<host<<" on port "<<port;

    socket_tcp.connectToHost(host,port);
}

/*
 * Fire this  when connected socket want to be closed
*/
void TCPClient_1::disconnect()
{
    socket_tcp.close();
    qWarning()<< "closed socket";


}

void TCPClient_1::write(const QByteArray &data)
{
    socket_tcp.write(data);
}

/*
 * Fire this  when client connected
*/
void TCPClient_1::connected()
{
    qInfo()<< "Connected";

    qInfo()<< "Sending";
//    socket_tcp.write("Hello\r\n");

}
/*
 * Fire this  when client disconnected
*/
void TCPClient_1::disconnected()
{
    qInfo()<< "Disconnected";
}
/*
 * Fire this when connecting to socket has an error
*/
void TCPClient_1::error(QAbstractSocket::SocketError socketError)
{
    qCritical()<< "Error:"<<socketError<<" "<<socket_tcp.errorString();
}
/*
 * Fire this  when the state of connection is changed
*/
void TCPClient_1::stateChanged(QAbstractSocket::SocketState socketState)
{
//    QMetaEnum metaEnum=QMetaEnum::fromType<QAbstractSocket::SocketState>();

//    qInfo()<<"State: "<<metaEnum.valueToKey(socketState);

    emit StateChanged(socketState);
}
/*
*Fire this signal  once every time new data is available for reading from the device
*/
void TCPClient_1::readyRead()
{
    QByteArray datagram;
    QByteArray datagram2;
    //    qInfo()<<"Data from: "<<sender()<<" bytes"<<socket_tcp.bytesAvailable();
    datagram=socket_tcp.readAll();
//        qInfo()<<"Data: "<<datagram2;
    newPacketReceived(datagram.toHex());
    newPacketReceived(datagram2.toHex());
}



