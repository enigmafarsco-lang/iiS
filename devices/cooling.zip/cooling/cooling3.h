#ifndef COOLING3_H
#define COOLING3_H

#include <QWidget>
#include "usertype.h"
#include "packetmanager.h"
#include <QTimer>

#define _HEADER_ 0xAABB
#define _FOOTER_ 0xCCDD


namespace Ui {
class Cooling3;
}

class Cooling3 : public QWidget
{
    Q_OBJECT


public:
    explicit Cooling3(QWidget *parent = nullptr);
    ~Cooling3();

private:

    bool autoMode{true};
    typedef enum _FC_
    {
        FC_ACK= 0,
        FC_ReadMultReg=2,
        FC_WriteMultReg=4,
        FC_ReadSetting,
        FC_WriteSetting ,
        FC_ReadBroadcast ,
        FC_WriteBroadcast ,
        FC_WriteCalibXY  ,
        FC_ReadCalibXY  ,
        FC_RestartModual
    }FC_t;


    typedef enum _STATUS_
    {
        NON=0,
        ON=100,
        OFF=200
    }status_t;

    enum on_off_status
    {
        Cooler_On=0,
        Cooler_Off=1
    };

int i{};
    on_off_status status_mode;

    bool creatPacket(uint8_t slaveNumber,uint8_t *data,uint8_t Packetlen,FC_t fc);

    packetManager pManager ;
    void reloadeDefaultGui();
    QTimer timerSendCoolerData;

    Ui::Cooling3 *ui;

private:
    int count {};
    bool isCoolerConnected{false};

private slots:
    void on_BtnAuto_clicked();
    void on_BtnManual_clicked();
    void on_BtnTurnOnCooling_clicked();
    void on_BtnTurnOffCooling_clicked();
    void GuiUpdate(packetManager::CoolingBoard_t);
    void sendCoolerDataSlot();
    
    void on_pushButton_clicked();


public slots:
    void on_DeviceResponseSlot(QByteArray);
    void connectionStatusSlot(bool);
//    void getData(QByteArray);

signals:
    void sendCommandToDeviceSignal(QByteArray);
    void newPacketReceived(QByteArray);

};

#endif // COOLING3_H
